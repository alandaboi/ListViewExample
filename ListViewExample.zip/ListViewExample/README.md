# ListViewExample
ListView is one of the layout like linear or relative, but to fill this one with data you will need to use adapters.

check these two links
1) https://developer.android.google.cn/guide/topics/ui/declaring-layout.html#AdapterViews
2) https://developer.android.google.cn/reference/android/widget/ListView

Assignment is to find a partner and FORK my repository, devide the work between two people, there are 13 todos over 5 files.
One of the students will create a repository but both students need to commit from their own account to this repository.

Learning objective:
1) devide and concor the tasks 
2) learn about the listview

if any students is left alone , he should join a group of two. I will allowe only one group of 3 students and no single student.
The code will not build successfully at this moment, you both need to figure out how does listview and adapters work.

Here is a great example that you might use
https://demonuts.com/android-custom-arrayadapter/

Students that cannot be in the same group

Alan, Jimmy, Jesse, David, Sunny.
and Ronal and Colin cannot form a pair.
